prov = ['辽宁省','吉林省','河北省','河南省','湖北省','湖南省','山东省','山西省','陕西省','安徽省',
'浙江省','江苏省','福建省','广东省','海南省','四川省','云南省','贵州省','青海省',
'甘肃省','江西省','台湾省','北京市','上海市','天津市','重庆市']

for pro in prov:
    print('。 O')
    print('在 O')
    for ind, item in enumerate(list(pro)):
        if ind==0:
            print(item,'B-LOC')
        elif ind == 1:
            print(item,'M-LOC')
        else:
            print(item,'E-LOC')
    