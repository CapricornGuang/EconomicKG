from data import build_corpus
from crf import CRFModel
from utils import load_model


def seperate(sentences):
    char_segment = []
    sentence_segment = sentences.split('。')
    for sent in sentence_segment:
        if sent == '':
            continue
        char_segment.append(list(sent))
    return char_segment

def predict(sentence):
    crf_model = CRFModel()
    crf_model = load_model(".\src\model\ckpts\crf.pkl")
    test_word_lists = seperate(sentence)
    pred_tag_lists = crf_model.test(test_word_lists)
    return pred_tag_lists

if __name__ == '__main__':
    tgt = '许亮在哪家公司担任法人代表'
    print(tgt)
    print(predict(tgt))