from mlp import MLP
from gensim.models import KeyedVectors
import paddlehub as hub
from paddlehub.reader.tokenization import load_vocab
import paddle.fluid as fluid
from os.path import abspath,join
import torch.nn as nn
import torch
import numpy as np


def getToneOf(word,skipgram,model):
	'''
	return 0 stands for ask
	return 1 stands for asert
	'''
	#print(help(skipgram))
	word_emb = torch.tensor(skipgram.word_vec(word))
	y_hat = model(word_emb)
	res = torch.argmax(y_hat).item()
	if res == 0:
		return 'ask'
	else:
		return 'asert'

def getQueryOf(word,skipgram,model):
	word_emb = torch.tensor(skipgram.word_vec(word))
	y_hat = model(word_emb)
	res = torch.argmax(y_hat).item()
	if res == 0:
		return 'company'
	else:
		return 'industry'

if __name__ == '__main__':
	
	skipgram = KeyedVectors.load_word2vec_format(abspath('.')+"\src\model\word_model\skipgram.bin", \
				binary = True, encoding = "utf-8", unicode_errors = "ignore")

	model = MLP()

	PATH = '.\src\model\ckpts\mlp2.pt'
	model.load_state_dict(torch.load(PATH))

	print(getQueryOf('集团',skipgram,model))
	

	
