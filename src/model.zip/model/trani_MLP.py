import torch.nn as nn
import torch
import numpy as np
import random

from torch.nn import init
from gensim.models import KeyedVectors
from os.path import abspath,join
from data import MLP_data
from mlp import MLP

def data_iter(batch_size, features, labels):
    num_examples = len(features)
    indices = list(range(num_examples))
    random.shuffle(indices)  
    for i in range(0, num_examples, batch_size):
        j = torch.LongTensor(indices[i: min(i + batch_size, num_examples)]) 
        yield  features.index_select(0, j), labels.index_select(0, j)


skipgram = KeyedVectors.load_word2vec_format(abspath('.')+"\src\model\word_model\skipgram.bin", \
			binary = True, encoding = "utf-8", unicode_errors = "ignore")

#print(skipgram.word_vec('苹果'))
'''
数据构造
'''
words, tgt = MLP_data(file="train.word2.clf")
tgt = torch.tensor(tgt)
word_emb = []
for word in words:
    word_emb.append(skipgram.word_vec(word))
word_emb = torch.tensor(word_emb)

'''
模型构造与参数初始化
'''
dim,clf = 100,2
net = MLP(dim,clf)
for params in net.parameters():
    init.normal_(params, mean=0, std=0.01)
    
'''
优化器构造
'''
epoch_num = 10
batch_size = 30
loss = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(net.parameters(), lr=0.5)

'''
模型训练
'''
for epoch in range(epoch_num):
    Iterator = data_iter(batch_size=20,features=word_emb,labels=tgt)
    tran_l_sum,batch_count = 0.0,0
    for X,y in Iterator:
        y_hat = net(X)
        l = loss(y_hat,y)
        optimizer.zero_grad()
        l.backward()
        optimizer.step()
        tran_l_sum += l.item()
        batch_count += 1
    print('loss:{}'.format(tran_l_sum/batch_count))

'''
保存模型
'''
PATH = '.\src\model\ckpts\mlp2.pt'
torch.save(net.state_dict(),PATH)

