import torch.nn as nn
import torch

class MLP(nn.Module):
    def __init__(self,dim=100,clf=2):
        super(MLP, self).__init__()
        num_inputs, num_outputs = dim, dim
        num_hiddens = int(dim/3)
        classNm = clf
        self.net = nn.Sequential(
            nn.Linear(num_inputs, num_hiddens),
            nn.ReLU(),
            nn.Linear(num_hiddens, num_outputs), 
            nn.Linear(num_outputs,classNm)
        )

    def forward(self,X):
        X_hat  = self.net(X)
        return X_hat


def getToneOf(word,skipgram,model):
	'''
	return 0 stands for ask
	return 1 stands for asert
	'''
	word_emb = torch.tensor(skipgram.word_vec(word))
	y_hat = model(word_emb)
	res = torch.argmax(y_hat).item()
	if res == 0:
		return 'ask'
	else:
		return 'asert'
