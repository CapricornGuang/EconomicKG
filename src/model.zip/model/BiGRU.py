import paddlehub as hub
from paddlehub.reader.tokenization import load_vocab
import paddle.fluid as fluid
import numpy as np

def analysis(lac,sentence):
    texts = [sentence]
    inputs = {"text":texts}
    results = lac.lexical_analysis(data=inputs)
    
    seg_word = [result['word'] for result in results]
    seg_lex =  [result['tag'] for result in results]
    return seg_word, seg_lex

def cos_sim(vector_a, vector_b):
    
    vector_a = np.mat(vector_a)
    vector_b = np.mat(vector_b)
    num = float(vector_a * vector_b.T)
    denom = np.linalg.norm(vector_a) * np.linalg.norm(vector_b)
    cos = num / denom
    return cos


def similarity_word(skipgram, tgt, src, vocab, program_section1, program_section2, program_section3):
    '''
    program_section1: (inputs, outputs, program)
    program_section2: (word_ids, embedding)
    program_section3: (place, exe, feeder)
    '''
    inputs, outputs, program = program_section1
    word_ids, embedding = program_section2
    place, exe, feeder = program_section3

    tgt_idx = [vocab[tgt]]
    src_idx = [vocab[src]]
    vecs = []
    print(tgt_idx)
    for lst_idx in (tgt_idx,src_idx):
        vecs_item, = exe.run(program,feed=feeder.feed([[lst_idx]]),fetch_list=[embedding.name],return_numpy=False)
        vecs.append(np.array(vecs_item))
    return cos_sim(vecs[0], vecs[1])

if __name__ == '__main__':
    skipgram = hub.Module(name="word2vec_skipgram")
    vocab = load_vocab(skipgram.get_vocab_path())
    inputs, outputs, program = skipgram.context(trainable=False,max_seq_len=1)

    fluid.disable_dygraph()
    word_ids = inputs["text"]
    embedding = outputs["emb"]

    place = fluid.CPUPlace()  
    exe = fluid.Executor(place)  
    feeder = fluid.DataFeeder(feed_list=[word_ids], place=place)

    sec1 = (inputs, outputs, program)
    sec2 = (word_ids, embedding)
    sec3 = (place, exe, feeder)

    stop = 0
    while(not stop):
        word1 = input('第一个词:')
        word2 = input('第二个词:')
        try:
            print(similarity_word(skipgram,word1,word2,vocab,sec1,sec2,sec3))
        except KeyError:
            print('输入另一个词!')
        stop = int(input('是否结束?'))
