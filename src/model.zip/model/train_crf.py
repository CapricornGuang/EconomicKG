from data import build_corpus
from crf import CRFModel
from utils import save_model


def crf_train_eval(train_data, test_data, remove_O=False):

    # 训练CRF模型
    train_word_lists, train_tag_lists = train_data
    test_word_lists, test_tag_lists = test_data

    crf_model = CRFModel()
    crf_model.train(train_word_lists, train_tag_lists)
    save_model(crf_model, ".\model\ckpts\crf.pkl")

    pred_tag_lists = crf_model.test(test_word_lists)
    return pred_tag_lists



print("读取数据...")
'''
此处有可能出现文件路径不对的bug, 文件肯定是在的！用os.path.abspath('.')检查一下python取的路径
'''
train_word_lists, train_tag_lists, word2id, tag2id = build_corpus("train")

test_word_lists, test_tag_lists = build_corpus("test", make_vocab=False)

crf_pred = crf_train_eval(
    (train_word_lists, train_tag_lists),
    (test_word_lists, test_tag_lists)
)
print(test_tag_lists)