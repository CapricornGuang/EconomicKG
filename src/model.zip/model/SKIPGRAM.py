import paddlehub as hub
from paddlehub.reader.tokenization import load_vocab
import paddle.fluid as fluid
import numpy as np
from os.path import abspath,join
from gensim.models import KeyedVectors


def cos_sim(vector_a, vector_b):
    
    vector_a = np.mat(vector_a)
    vector_b = np.mat(vector_b)
    num = float(vector_a * vector_b.T)
    denom = np.linalg.norm(vector_a) * np.linalg.norm(vector_b)
    cos = num / denom
    return cos


def similarity_word128(skipgram, tgt, src, vocab, program_section1, program_section2, program_section3):
    '''
    program_section1: (inputs, outputs, program)
    program_section2: (word_ids, embedding)
    program_section3: (place, exe, feeder)
    '''
    inputs, outputs, program = program_section1
    word_ids, embedding = program_section2
    place, exe, feeder = program_section3

    tgt_idx = [vocab[tgt]]
    src_idx = [vocab[src]]
    vecs = []
    print(tgt_idx)
    for lst_idx in (tgt_idx,src_idx):
        vecs_item, = exe.run(program,feed=feeder.feed([[lst_idx]]),fetch_list=[embedding.name],return_numpy=False)
        vecs.append(np.array(vecs_item))
    return cos_sim(vecs[0], vecs[1])

def similarity_word100(skipgram, tgt, src):
    return skipgram.similarity(tgt, src)

def top_semantic100_noun(skipgram, seg_word, seg_lex):
    semantic_word = [ ]
    alternative = []
    for idx, lex in enumerate(seg_lex):
        if lex in ['n','nr','ns']:
            semantic_word.append(seg_word[idx])
        if lex == 'n':
            alternative.append(seg_word[idx])

    semantic_emb = np.array([skipgram.word_vec(word) for word in semantic_word]).mean(axis=0)
    alternative_emb = np.array([skipgram.word_vec(word) for word in alternative])
    score = alternative_emb.dot(semantic_emb.T)
    return alternative[np.argmax(score)]



def top_semantic128_noun(skipgram, seg_word, seg_lex,vocab, program_section1,program_section2,program_section3):
    semantic_word = [ ]
    alternative = []
    for idx, lex in enumerate(seg_lex):
        if lex in ['n','nr','ns','ORG','nz','vn']:
            semantic_word.append(seg_word[idx])
        if lex == 'n' or lex == 'nz' or lex =='vn':
            alternative.append(seg_word[idx])

    inputs, outputs, program = program_section1
    word_ids, embedding = program_section2
    place, exe, feeder = program_section3


    alternative_emb = []
    for tgt in alternative:
        tgt_idx = [vocab[tgt]]
        alternative_emb_item, = exe.run(program,feed=feeder.feed([[tgt_idx]]),fetch_list=[embedding.name],return_numpy=False)
        alternative_emb_item = np.array(alternative_emb_item)
        #print(alternative_emb_item.shape)
        alternative_emb.append(alternative_emb_item)
    alternative_emb = np.array(alternative_emb).reshape(-1, 128)

    semantic_emb = []
    for src in semantic_word:
        try:
            src_idx = [vocab[src]]
        except KeyError:
            src_idx = [vocab['[UNK]']]
        semantic_emb_item, = exe.run(program,feed=feeder.feed([[src_idx]]),fetch_list=[embedding.name],return_numpy=False)
        semantic_emb_item = np.array(semantic_emb_item)
        semantic_emb.append(semantic_emb_item)
    semantic_emb = np.array(semantic_emb).mean(axis=0).reshape(-1,128)
    

    score = alternative_emb.dot(semantic_emb.T)
    if alternative == []:
        return None
    else:
        return alternative[np.argmax(score)]



if __name__ == '__main__':
    print('start loading skipgram128')
    skipgram = hub.Module(name="word2vec_skipgram")
    vocab = load_vocab(skipgram.get_vocab_path())
    inputs, outputs, program = skipgram.context(trainable=False,max_seq_len=1)

    fluid.disable_dygraph()
    word_ids = inputs["text"]
    embedding = outputs["emb"]

    place = fluid.CPUPlace()  
    exe = fluid.Executor(place)  
    feeder = fluid.DataFeeder(feed_list=[word_ids], place=place)

    sec1 = (inputs, outputs, program)
    sec2 = (word_ids, embedding)
    sec3 = (place, exe, feeder)

    print('start loading skipgram100')
    skipgram = KeyedVectors.load_word2vec_format(abspath('.')+"\src\model\word_model\skipgram.bin", \
			binary = True, encoding = "utf-8", unicode_errors = "ignore")
    '''
    #判断两个词汇的相似度的小程序
    stop = 0
    while(not stop):
        word1 = input('第一个词:')
        word2 = input('第二个词:')
        try:
            print(similarity_word100(skipgram,word1,word2))
        except KeyError:
            print('输入另一个词!')
        stop = int(input('是否结束?'))
    '''
    #计算最重要的词
    print('start abstracting the most important none')
    seg_word = ['有', '哪些', '科技','企业', '在', '广东']
    seg_lex = ['v', 'r', 'n','n', 'p', 'LOC']
    res = top_semantic128_noun(skipgram,seg_word,seg_lex,vocab,sec1,sec2,sec3)
    print(res)
